# Pygame × AI 2D Platformer Research

Python / Pygame を使用して、**マリオ風の2D横スクロールアクションゲーム**を開発する。

本プロジェクトではゲーム制作だけを目的とせず、完成したゲームをAIの実験環境として利用する。

最終的には、

* AIによるプレイヤー自動操作
* AIによる敵キャラクター制御
* プレイヤーの行動パターン学習
* プレイヤーに合わせた自動難易度調整
* AIによる自動ゲームテスト

を実装し、**AIがゲームをプレイ・学習・分析・調整・テストできるシステム**を構築する。

> ※ゲームは「マリオ風」のゲームシステムを参考にしたオリジナル作品とし、任天堂のキャラクター・画像・音源・ステージなどをそのまま使用しない。

---

# 1. プロジェクトの目的

Pygameで2D横スクロールアクションゲームを制作し、そのゲームをAIの学習・評価環境として利用する。

単純に「AIにゲームをプレイさせる」のではなく、

```text
ゲーム制作
    ↓
AIが操作
    ↓
ゲームデータ収集
    ↓
機械学習
    ↓
プレイヤー行動分析
    ↓
難易度自動調整
    ↓
AIによる大量プレイ
    ↓
自動テスト
```

という一連のシステムを構築する。

---

# 2. 最終目標

最終的には以下のようなシステムを目指す。

```text
                         ┌──────────────────┐
                         │  2D Platformer   │
                         │     Pygame       │
                         └────────┬─────────┘
                                  │
               ┌──────────────────┼──────────────────┐
               │                  │                  │
               ▼                  ▼                  ▼
          ゲーム状態          プレイヤー情報       敵情報
               │                  │                  │
               ▼                  ▼                  ▼
        ┌────────────┐      ┌────────────┐     ┌────────────┐
        │  Player AI │      │  ML Model  │     │  Enemy AI  │
        └─────┬──────┘      └─────┬──────┘     └─────┬──────┘
              │                   │                  │
              │                   ▼                  │
              │            行動パターン分析         │
              │                   │                  │
              └───────────────────┼──────────────────┘
                                  ▼
                         ┌────────────────┐
                         │ Difficulty AI  │
                         └───────┬────────┘
                                 │
                                 ▼
                          ゲームへ反映
                                 │
                                 ▼
                         ┌────────────────┐
                         │  Test Agent    │
                         └───────┬────────┘
                                 │
                                 ▼
                           自動テスト結果
```

---

# 3. ゲームの基本仕様

ゲームのベースは、**マリオ風の2D横スクロールアクション**とする。

## 基本要素

### プレイヤー

* 左右移動
* ジャンプ
* 重力
* 落下
* 敵との接触
* HP / 残機
* ゴール到達

### ステージ

* 地面
* 足場
* ブロック
* 穴
* 障害物
* ゴール
* 横スクロール

### 敵

* プレイヤーを追跡
* 左右移動
* プレイヤーへの攻撃
* 複数種類への拡張

---

# 4. ゲーム設計

AI研究に利用するため、ゲームとAIを分離する。

```text
pygame-ai-platformer/
│
├── README.md
├── pyproject.toml
│
├── src/
│   └── pygame_ai_platformer/
│       ├── game/
│       │   ├── game.py
│       │   ├── player.py
│       │   ├── enemy.py
│       │   ├── stage.py
│       │   ├── camera.py
│       │   └── state.py
│       │
│       ├── ai/
│       │   ├── agent.py
│       │   ├── random_agent.py
│       │   ├── rule_agent.py
│       │   ├── ml_agent.py
│       │   └── rl_agent.py      # Phase8で追加予定
│       │
│       ├── logger.py
│       ├── collect_data.py
│       ├── train_ml_agent.py
│       ├── main.py
│       └── ai_demo.py
│
├── data/
│   ├── player/
│   └── training/
│
├── models/
│
├── experiments/
│
├── logs/
│
└── tests/
```

---

# 5. AI用ゲームAPI

AIからゲームを操作できるようにする。

例えば、

```python
game.reset()

state = game.get_state()

next_state, reward, done = game.step(action)
```

というインターフェースを用意する。

## `reset()`

ゲームを初期状態に戻す。

```python
game.reset()
```

## `get_state()`

現在のゲーム状態を取得する。

例：

```python
{
    "player_x": 100,
    "player_y": 300,
    "velocity_x": 0,
    "velocity_y": 0,
    "enemies": [...],
    "nearby_blocks": [...],
    "goal_distance": 1000,
    "hp": 3
}
```

## `step(action)`

AIから1つの行動を受け取り、ゲームを進める。

```python
state, reward, done = game.step(action)
```

---

# 6. AIの行動

最初は以下程度にする。

```text
LEFT
RIGHT
JUMP
NONE
```

将来的には、

```text
LEFT
RIGHT
JUMP
LEFT + JUMP
RIGHT + JUMP
ATTACK
```

などへ拡張する。

---

# 7. Phase 1 — ゲーム制作 ✅完了

まずAIを作らず、ゲームそのものを完成させる。

## 実装するもの

```text
[x] Pygameのゲームループ
[x] プレイヤー
[x] 左右移動
[x] ジャンプ
[x] 重力
[x] 衝突判定
[x] 足場
[x] 穴
[x] 敵
[x] ゴール
[x] カメラ
[x] 横スクロール
[x] ゲームオーバー
[x] リスタート
```

この段階では普通にキーボードでプレイできるようにする。

`src/pygame_ai_platformer/game/` に実装済み。`uv run play` で起動できる。

---

# 8. Phase 2 — AIによる自動操作 ✅完了(RandomAgent)

AIからゲームを操作できるようにする。

まずはランダムAIを作る。

```text
        ┌─────────────┐
        │    Game     │
        └──────┬──────┘
               │
             State
               ↓
        ┌─────────────┐
        │ Random Agent│
        └──────┬──────┘
               │
             Action
               ↓
             Game
```

例えば、

```python
action = random.choice([
    "LEFT",
    "RIGHT",
    "JUMP",
    "NONE"
])
```

とする。

これは後のAIと比較するための**ベースライン**にもなる。

`src/pygame_ai_platformer/ai/random_agent.py` に実装済み。`uv run ai-demo` で動作確認できる。

---

# 9. Phase 3 — ルールベースAI ✅完了

次に、人間が決めたルールでゲームを攻略するAIを作る。

例えば、

```text
敵が左にいる
    ↓
右へ移動

敵が右にいる
    ↓
左へ移動

穴が近い
    ↓
ジャンプ

敵が近い
    ↓
ジャンプ
```

のようなルールを実装する。

これによって、

```text
Random AI
    VS
Rule-based AI
```

を比較できる(RuleAgentは100/100エピソードでクリア、RandomAgentは0/100)。

`src/pygame_ai_platformer/ai/rule_agent.py` に実装済み。

---

# 10. Phase 4 — 機械学習 ✅完了(データ収集まで)

プレイヤーの操作データを収集する。

## 収集するデータ

```text
プレイヤーのX座標
プレイヤーのY座標
X方向速度
Y方向速度
敵との距離
敵の位置
周囲の足場
ゴールまでの距離
HP
プレイヤーの操作
```

例えば、

```csv
time,x,y,velocity_x,velocity_y,enemy_distance,goal_distance,action
0,100,300,0,0,300,1200,RIGHT
1,105,300,5,0,295,1195,RIGHT
2,110,300,5,0,290,1190,JUMP
3,110,280,0,-10,285,1190,RIGHT
```

のように保存する。

`src/pygame_ai_platformer/logger.py`(記録)と`src/pygame_ai_platformer/collect_data.py`
(収集スクリプト)に実装済み。`uv run collect-data --episodes 50 --agent rule` で
`data/training/rule/` 以下にエピソード単位のCSVが溜まっていく(エージェントごとに
サブディレクトリを分けて保存する)。

---

# 11. Phase 5 — プレイヤー行動予測 ✅完了(RuleAgentの模倣まで)

収集したデータを機械学習モデルに学習させる。

```text
ゲーム状態
    ↓
機械学習モデル
    ↓
次のプレイヤー行動
```

例えば、

```text
敵との距離 = 100
敵の位置 = 右
プレイヤー速度 = 5
穴までの距離 = 50

        ↓

モデル

        ↓

JUMP
```

のように予測する。

## 最初に試すモデル

* Decision Tree
* Random Forest
* その他の分類アルゴリズム

その後、必要に応じてニューラルネットワークへ発展させる。

`src/pygame_ai_platformer/collect_data.py`でエージェントごとに
`data/training/<agent名>/`へCSVを分けて保存し、
`src/pygame_ai_platformer/train_ml_agent.py`がそれを読み込んで
DecisionTree/RandomForestを学習、`models/player_action_model.joblib`に保存する。
`src/pygame_ai_platformer/ai/ml_agent.py`がそのモデルを読み込んで`predict(state)`する
`MLAgent`を提供する。

現状はRuleAgentのプレイを模倣学習させており(教師データがRuleAgent由来なので
精度はほぼ100%、30/30エピソードでクリア)、次のステップとして人間のプレイデータを
`uv run collect-data --agent human`(要実装)のような形で収集し、
人間らしい行動を学習させることを検討中。

```bash
uv run collect-data --episodes 60 --agent rule   # data/training/rule/ にCSVが溜まる
uv run train-ml --model decision_tree            # models/player_action_model.joblib を作成
uv run ai-demo --agent ml                         # 学習済みモデルでプレイを確認
```

---

# 12. Phase 6 — プレイヤーを学習する敵

Phase 5で作ったモデルを敵AIに利用する。

```text
プレイヤー
    ↓
行動データ
    ↓
機械学習
    ↓
プレイヤーの行動予測
    ↓
敵AI
    ↓
プレイヤーに合わせた行動
```

例えば、

```text
プレイヤーが敵に近づく
        ↓
過去のデータから
「ジャンプする可能性が高い」
        ↓
敵がジャンプ先を予測
        ↓
迎撃
```

という仕組みを目指す。

---

# 13. Phase 7 — 自動難易度調整

プレイヤーのプレイデータを利用して、ゲームの難易度を自動調整する。

## 取得するデータ

```text
死亡回数
クリア時間
被ダメージ
敵撃破数
ジャンプ成功率
攻撃成功率
ステージ到達距離
```

## 難易度パラメータ

```text
敵のHP
敵の速度
敵の数
敵の攻撃頻度
敵の出現位置
プレイヤーHP
アイテム出現率
ステージの長さ
```

例えば、

```text
プレイヤーの死亡率が高い
        ↓
難易度を下げる
```

または、

```text
プレイヤーがほぼノーダメージでクリア
        ↓
難易度を上げる
```

という仕組みを作る。

---

# 14. Phase 8 — AIによる自動ゲームテスト

AIにゲームを大量にプレイさせる。

```text
AI
 ↓
Game
 ↓
AI
 ↓
Game
 ↓
AI
 ↓
Game
 ↓
...
```

例えば、

```python
for episode in range(10000):
    game.reset()

    while not game.finished:
        action = agent.predict(state)
        state, reward, done = game.step(action)

    save_result()
```

とする。

---

# 15. 自動テストで検出するもの

AIによる大量プレイから異常を検出する。

```text
[ ] プレイヤーが画面外へ出る
[ ] プレイヤーが壁に埋まる
[ ] プレイヤーが地面をすり抜ける
[ ] プレイヤーが永久に落下する
[ ] HPが不正な値になる
[ ] スコアが異常な値になる
[ ] ステージがクリア不能になる
[ ] ゲームが停止する
[ ] 敵が想定外の位置へ移動する
```

異常が発生した場合、

```text
episode
score
player_position
enemy_position
state
action
```

などをログに保存する。

---

# 16. 強化学習

最終的には強化学習によるAI操作にも挑戦する。

基本構造：

```text
        State
          ↓
        Agent
          ↓
        Action
          ↓
        Game
          ↓
       Reward
          ↓
        Agent
```

例えば報酬を、

```text
ゴール到達       +100
敵を倒す          +10
コイン取得         +5
前進                +1
ダメージ           -10
死亡              -100
```

などと設定する。

AIは報酬を最大化するように行動を学習する。

---

# 17. AI手法の比較

研究では複数の手法を比較する。

```text
Random Agent
      │
      ├─────────────┐
      ↓             ↓
Rule-based AI   Machine Learning
                      │
                      ↓
              Reinforcement Learning
```

## 比較項目

| 項目     | 内容            |
| ------ | ------------- |
| クリア率   | ゲームをクリアできた割合  |
| 平均スコア  | 1プレイあたりの平均スコア |
| 平均到達距離 | どこまで進めたか      |
| クリア時間  | ゴールまでに必要な時間   |
| 学習時間   | モデルの学習に必要な時間  |
| 試行回数   | 学習に必要なプレイ回数   |
| 汎化性能   | 未知のステージでの性能   |
| 計算コスト  | CPU・メモリ使用量    |

---

# 18. 研究としてのポイント

このプロジェクトでは、

> 「AIを使えばゲームを上手くプレイできる」

だけを結論にしない。

以下を実験・比較する。

```text
どのAIがどの状況に強いのか？

機械学習によって
プレイヤーの行動を予測できるのか？

プレイヤーに合わせた
難易度調整は可能なのか？

AIによる大量プレイによって
人間が発見しにくい問題を発見できるのか？
```

---

# 19. 技術スタック

## ゲーム

```text
Python
Pygame
```

## データ処理

```text
NumPy
pandas
```

## 機械学習

```text
scikit-learn
```

## ニューラルネットワーク

```text
PyTorch
```

## 強化学習

```text
Gymnasium
```

## 開発・管理

```text
Git
GitHub
uv
pytest
```

---

# 20. 開発ロードマップ

```text
┌─────────────────────────────┐
│ Phase 1                     │
│ マリオ風2Dゲーム制作        │
└──────────────┬──────────────┘
               ↓
┌─────────────────────────────┐
│ Phase 2                     │
│ Game API                    │
│ reset / state / step        │
└──────────────┬──────────────┘
               ↓
┌─────────────────────────────┐
│ Phase 3                     │
│ Random / Rule-based AI      │
└──────────────┬──────────────┘
               ↓
┌─────────────────────────────┐
│ Phase 4                     │
│ プレイヤーデータ収集        │
└──────────────┬──────────────┘
               ↓
┌─────────────────────────────┐
│ Phase 5                     │
│ 機械学習による行動予測      │
└──────────────┬──────────────┘
               ↓
┌─────────────────────────────┐
│ Phase 6                     │
│ プレイヤー適応型Enemy AI    │
└──────────────┬──────────────┘
               ↓
┌─────────────────────────────┐
│ Phase 7                     │
│ 自動難易度調整              │
└──────────────┬──────────────┘
               ↓
┌─────────────────────────────┐
│ Phase 8                     │
│ 強化学習AI                  │
└──────────────┬──────────────┘
               ↓
┌─────────────────────────────┐
│ Phase 9                     │
│ AI自動ゲームテスト          │
└──────────────┬──────────────┘
               ↓
┌─────────────────────────────┐
│ AI Game Research            │
└─────────────────────────────┘
```

---

# 21. 最初の目標

まずはAIを一切使わず、**普通に遊べる2D横スクロールゲーム**を完成させる。

```text
[x] Pygameゲームループ
[x] プレイヤー
[x] 左右移動
[x] ジャンプ
[x] 重力
[x] 足場
[x] 穴
[x] 敵
[x] 衝突判定
[x] カメラ
[x] 横スクロール
[x] ゴール
[x] ゲームオーバー
[x] リスタート
```

その後、

```text
[x] game.reset()
[x] game.get_state()
[x] game.step(action)
```

を実装する。

ここまで完成すれば、**AIをゲームへ接続する準備が完了**する。 → 完了。
現在はPhase5(RuleAgentの模倣学習)まで完了しており、Phase6(プレイヤーを学習する敵)に着手予定。

---

# 22. 最終的なプロジェクト

最終的には、

```text
Pygame
  ↓
2D Platformer
  ↓
Game Environment
  │
  ├── Player AI
  │      └── 自動操作
  │
  ├── Enemy AI
  │      └── 敵の自動制御
  │
  ├── Machine Learning
  │      └── プレイヤー行動学習
  │
  ├── Difficulty AI
  │      └── 自動難易度調整
  │
  └── Test Agent
         └── 自動ゲームテスト
```

という構成を目指す。

## Goal

**マリオ風2D横スクロールゲームをAIの実験環境として構築し、AIによるゲームプレイ・敵制御・行動予測・難易度調整・自動テストまでを一つのシステムとして実現する。**

